import javax.swing.*;
import java.awt.*;

public class ExemploNormal2 {

    ExemploNormal2(){

        // JFRAME

        JFrame frame = new JFrame("Exemplo Painel");
        frame.setSize(400, 400);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();

        JPanel painel1 = new JPanel();
        JPanel painel2 = new JPanel();
        painel1.setBackground(Color.yellow);
        painel2.setBackground(Color.red);

        // JTABBEDPANE

        JTabbedPane tp = new JTabbedPane();
        tp.setBounds(50, 50, 200, 200);
        tp.setVisible(true);
        tp.add("Guia1", painel1); // nome da guia + painel
        tp.add("Guia2", painel2);

        frame.add(tp);

    }

    public static void main(String[] args) {

        new ExemploNormal2();

    }
}
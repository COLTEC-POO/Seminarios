import javax.swing.*;

public class Exemplo1 {
    private JPanel painel;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Exemplo1");
        frame.setContentPane(new Exemplo1().painel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

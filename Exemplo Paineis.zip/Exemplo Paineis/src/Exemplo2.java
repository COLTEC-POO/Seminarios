import javax.swing.*;

public class Exemplo2 {
    private JPanel painel;
    private JTabbedPane tabbedPane1;
    private JPanel Inicio;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Exemplo2");
        frame.setContentPane(new Exemplo2().painel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private JPanel Guia;
}

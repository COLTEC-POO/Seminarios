import javax.swing.*;

public class ExemploJPanel {
    private JPanel painel;

    public static void main(String[] args) {
        JFrame frame = new JFrame("ExemploJPanel");
        frame.setContentPane(new ExemploJPanel().painel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

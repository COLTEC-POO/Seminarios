import javax.swing.*;
import java.awt.*;

public class ExemploNormal1 {

    ExemploNormal1() {

        // JFRAME

        JFrame frame = new JFrame("Exemplo Painel");
        frame.setSize(400, 400);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();

        // OUTROS COMPONENTES
        JLabel texto = new JLabel("Bem-vindo!");
        texto.setPreferredSize(new Dimension(500, 500));
        texto.setFont(new Font("Verdana", Font.PLAIN, 40));
        JButton botao = new JButton("CLIQUE AQUI");
        botao.setBounds(100,130, 50,100);

        // JPANEL

        JPanel painel = new JPanel();

        painel.setBounds(50, 50, 200, 200); // tamanho e posição
        //painel.setSize(new Dimension(200, 200)); // tamanho
        painel.setBackground(Color.pink);
        painel.setVisible(true);
        painel.add(texto);
        painel.add(botao);

        // ADICIONA COMPONENTE
        frame.add(painel);

    }

    public static void main(String[] args) {


        new ExemploNormal1();


    }
}
